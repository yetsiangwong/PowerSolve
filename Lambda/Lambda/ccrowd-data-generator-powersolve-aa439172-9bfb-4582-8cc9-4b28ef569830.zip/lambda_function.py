import json, boto3, random
from datetime import datetime, timedelta

REGION = "ap-southeast-5"
RAW_BUCKET = "crowd-ctrl-raw-powersolve"        
TABLE_EVENTS = "crowd-event-status-powersolve"        
TABLE_VENUES = "crowd-venues-powersolve"              

s3 = boto3.client("s3", region_name=REGION)
dynamodb = boto3.resource("dynamodb", region_name=REGION)

def lambda_handler(event, context):
    seed_venues()
    seed_events()
    seed_transport_stub()
    return {"statusCode": 200, "body": "Sample data generated"}

def seed_venues():
    t = dynamodb.Table(TABLE_VENUES)
    venues = [
        {"venue_id":"bukit-jalil","name":"Bukit Jalil National Stadium",
         "capacity":87411,"entry_gates":8,"exit_gates":12,"food_courts":6,"restrooms":24,"parking_lots":4},
        {"venue_id":"klcc-cc","name":"KLCC Convention Centre",
         "capacity":15000,"entry_gates":4,"exit_gates":6,"food_courts":3,"restrooms":12,"parking_lots":2}
    ]
    for v in venues: t.put_item(Item=v)

def seed_events():
    t = dynamodb.Table(TABLE_EVENTS)
    now = datetime.utcnow()
    for i in range(120):
        item = {
            "event_id": f"evt-{i:03d}",
            "timestamp": int((now - timedelta(days=random.randint(1, 365))).timestamp()),
            "venue_id": random.choice(["bukit-jalil","klcc-cc"]),
            "event_type": random.choice(["concert","sports","conference","festival"]),
            "expected_attendance": random.randint(5000, 80000),
            "actual_attendance": random.randint(4000, 85000),
            "weather": random.choice(["sunny","rainy","cloudy"]),
            "peak_entry_time": f"{random.randint(18,20)}:{random.randint(0,59):02d}",
            "peak_exit_time": f"{random.randint(22,23)}:{random.randint(0,59):02d}"
        }
        t.put_item(Item=item)

def seed_transport_stub():
    # Copy your uploaded file into curated for downstream steps if needed
    s3.copy_object(
        Bucket=RAW_BUCKET,
        CopySource={"Bucket": RAW_BUCKET, "Key": "transport-schedules/mrt-schedule.json"},
        Key="ml-models/mrt-schedule.json"
    )

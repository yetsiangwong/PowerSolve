# crowd-publish-alerts (Python 3.12)
import os
import json
import logging
import boto3
from botocore.exceptions import ClientError

# Logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

REGION = os.environ.get("AWS_REGION", "ap-southeast-5")
s3 = boto3.client("s3", region_name=REGION)
sns = boto3.client("sns", region_name=REGION)

BUCKET = os.environ.get("OUTPUT_BUCKET")   # required
TOPIC = os.environ.get("SNS_ARN")          # required

def lambda_handler(event, context):
    logger.info("Received event: %s", json.dumps(event))
    prefix = event.get("s3_prefix")
    if not prefix:
        msg = "No s3_prefix provided in event."
        logger.error(msg)
        return {"statusCode": 400, "error": msg}

    actions_key = prefix.rstrip("/") + "/actions.json"   # ensure trailing slash safe
    logger.info("Reading actions from s3://%s/%s", BUCKET, actions_key)

    try:
        obj = s3.get_object(Bucket=BUCKET, Key=actions_key)
        body = obj["Body"].read().decode("utf-8")
        actions = json.loads(body)
        logger.info("Loaded actions.json (len=%d)", len(actions) if isinstance(actions, list) else 0)
    except ClientError as e:
        code = e.response.get("Error", {}).get("Code")
        logger.exception("Failed to read actions.json (%s)", code)
        # Publish a warning so operators know simulation produced no output or S3 is wrong
        warn = f"⚠️ Simulation outputs missing or unreadable for prefix {prefix} (S3:{code})"
        try:
            sns.publish(TopicArn=TOPIC, Subject="[CrowdCtrl] Simulation error", Message=warn)
        except Exception as se:
            logger.exception("Failed to publish SNS about missing actions.json")
        return {"statusCode": 502, "error": warn}

    # Build friendly message
    try:
        if not actions:
            msg = "✅ No crowd issues detected."
        else:
            lines = ["🔴 CROWD ALERTS"]
            # actions expected to be dicts with fields like action, gate, venue, severity
            for a in actions[:10]:
                gate = a.get("gate") or a.get("venue") or "unknown"
                action_text = a.get("action") or json.dumps(a)
                lines.append(f"- {action_text} (at {gate})")
            msg = "\n".join(lines)

        # Publish to SNS
        sns.publish(TopicArn=TOPIC, Subject="[CrowdCtrl] Scenario Actions", Message=msg)
        logger.info("Published SNS message (len=%d chars)", len(msg))
        return {"statusCode": 200, "msg": msg, "actions_count": len(actions)}
    except Exception as e:
        logger.exception("Unexpected error while processing actions")
        return {"statusCode": 500, "error": str(e)}

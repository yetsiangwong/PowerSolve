# crowd-simulate-scenario (CSV-friendly, robust S3 reader)
import os
import io
import json
import time
import csv
from collections import defaultdict
from datetime import datetime
import boto3
import logging
from botocore.exceptions import ClientError

# logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# config from env
REGION = os.environ.get("AWS_REGION", "ap-southeast-5")
RAW_BUCKET = os.environ.get("RAW_BUCKET")    # must be set in Lambda env
OUTPUT_BUCKET = os.environ.get("OUTPUT_BUCKET")  # must be set

# clients
s3 = boto3.client("s3", region_name=REGION)
cw = boto3.client("cloudwatch", region_name=REGION)

def read_s3_text(bucket, key, context=None):
    """
    Safe S3 text reader:
    - logs the exact bucket/key and request id
    - reads bytes and returns a decoded string with safe fallbacks
    - raises a clear RuntimeError for obvious binary/parquet files
    """
    request_id = getattr(context, "aws_request_id", "no-request-id")
    logger.info("About to read S3 object: bucket=%s key=%s aws_request_id=%s", bucket, key, request_id)

    try:
        obj = s3.get_object(Bucket=bucket, Key=key)
    except ClientError as e:
        code = e.response.get("Error", {}).get("Code", "")
        logger.exception("Failed to get s3://%s/%s (%s)", bucket, key, code)
        raise

    body_bytes = obj["Body"].read()
    content_type = obj.get("ContentType", "")
    logger.info("Read s3://%s/%s size=%d ContentType=%s", bucket, key, len(body_bytes), content_type)

    # If file appears to be binary (parquet etc.), raise a clear error
    if key.lower().endswith((".parquet", ".pq")) or ("parquet" in (content_type or "").lower()):
        logger.error("File appears to be binary/parquet; simulation expects text. key=%s content_type=%s", key, content_type)
        raise RuntimeError(f"Binary file read attempted: {key}")

    # Try decodes with fallbacks (won't crash)
    try:
        body = body_bytes.decode("utf-8")
    except UnicodeDecodeError:
        try:
            body = body_bytes.decode("utf-8-sig")   # handle BOM
        except UnicodeDecodeError:
            body = body_bytes.decode("latin-1", errors="replace")
            logger.warning("Decoded with latin-1/replace fallback for %s; file contains invalid UTF-8 bytes", key)

    return body

def put_metric(name, value, dims):
    cw.put_metric_data(Namespace="CrowdCtrl",
                       MetricData=[{"MetricName": name, "Dimensions": dims, "Value": float(value)}])

def lambda_handler(event, context):
    logger.info("Simulate event: %s", json.dumps(event))
    scenario = event.get("scenario","entry_rush")
    forecast_key = event.get("forecast_key","historical-events/entry_forecast.csv")  # default CSV
    gate_open = set(event.get("gate_open", []))
    closed_nodes = set(event.get("closed_nodes", []))

    # load venue nodes/edges using robust reader
    nodes_key = "venue-layouts/venue_nodes.csv"
    edges_key = "venue-layouts/venue_edges.csv"

    try:
        nodes_csv = read_s3_text(RAW_BUCKET, nodes_key, context)
        edges_csv = read_s3_text(RAW_BUCKET, edges_key, context)
    except ClientError:
        # S3 read error already logged
        return {"statusCode":500, "body": json.dumps({"error":"Failed to read venue files from S3"})}
    except RuntimeError as re:
        # explicit binary/parquet error or other runtime
        return {"statusCode":400, "body": json.dumps({"error": str(re)})}

    # parse nodes -> gate capacities
    nodes = {}
    gate_cap = {}
    for r in csv.DictReader(io.StringIO(nodes_csv)):
        nodes[r["node_id"]] = r
        if r.get("type","").strip().lower() == "gate":
            try:
                gate_cap[r["node_id"]] = int(r.get("gate_capacity_ppm") or r.get("capacity_ppm") or 120)
            except Exception:
                gate_cap[r["node_id"]] = 120

    # build adjacency structure
    adj = defaultdict(list)
    for r in csv.DictReader(io.StringIO(edges_csv)):
        if r["to"] in closed_nodes:
            continue
        adj[r["from"]].append((r["to"], int(r.get("walk_time_sec") or 60), int(r.get("capacity_ppm") or 120)))

    # --- READ forecast CSV from S3 using robust helper ---
    try:
        body = read_s3_text(RAW_BUCKET, forecast_key, context)
    except ClientError:
        return {"statusCode":400, "body": json.dumps({"error":f"Forecast key not found: {forecast_key}"})}
    except RuntimeError as re:
        return {"statusCode":400, "body": json.dumps({"error": str(re)})}

    reader = csv.DictReader(io.StringIO(body))
    # expected columns: timestamp, gate_id, arrivals
    forecast_rows = []
    for row in reader:
        try:
            ts = int(float(row.get("timestamp") or 0))
            gate = row.get("gate_id") or row.get("gate") or row.get("gateId")
            arrivals = int(float(row.get("arrivals") or 0))
            if gate and ts:
                forecast_rows.append((ts, gate, arrivals))
        except Exception:
            # skip bad rows
            continue
    if not forecast_rows:
        return {"statusCode":400, "body": json.dumps({"error":"No forecast rows found"})}

    # group by timestamp/gate
    df_group = defaultdict(lambda: defaultdict(int))
    tmin = None; tmax = None
    for ts, gate, arr in forecast_rows:
        df_group[ts][gate] += arr
        if tmin is None or ts < tmin: tmin = ts
        if tmax is None or ts > tmax: tmax = ts

    # simulation state
    Qgate = defaultdict(int)
    edge_load = defaultdict(int)
    hotspots = []
    actions = []

    # iterate minute-by-minute
    for t in range(tmin, tmax+60, 60):
        # arrivals this minute
        arrivals = df_group.get(t, {})
        for g, v in arrivals.items():
            if (not gate_open) or (g in gate_open):
                Qgate[g] += int(v)

        # gate processing
        for g in list(Qgate.keys()):
            cap = gate_cap.get(g, 120)
            served = min(Qgate[g], cap)
            Qgate[g] -= served
            if adj.get(g):
                to, walk, ecap = adj[g][0]
                moving = min(served, ecap)
                edge_load[(g,to)] += moving

        # detect hotspots, reset edge loads
        for (u,v), load in list(edge_load.items()):
            ecap = next((e[2] for e in adj[u] if e[0]==v), None)
            if ecap is None:
                continue
            if load > 0.8 * ecap:
                hotspots.append({"ts": t, "edge": f"{u}->{v}", "load": int(load), "cap": int(ecap),
                                 "severity": "HIGH" if load > ecap else "MED"})
            edge_load[(u,v)] = 0

        # gate wait metrics & actions
        for g, q in Qgate.items():
            wait_min = q / max(1, gate_cap.get(g, 120))
            put_metric("GateQueueMinutes", wait_min, [{"Name":"Gate","Value":g},{"Name":"Scenario","Value":scenario}])
            if wait_min >= 10:
                actions.append({"ts": t, "action": f"Open extra lane near {g} or redirect to less busy gate", "gate": g, "pred_wait_min": round(wait_min,1)})

    # --- Evacuation planner (replace the single generic action) ---
    if scenario == "evacuation":
        # helper: parse numeric coords safely
        def coord(node_id):
            n = nodes.get(node_id, {})
            try:
                return float(n.get("x") or 0.0), float(n.get("y") or 0.0)
            except Exception:
                return 0.0, 0.0

        def dist(a,b):
            return ((a[0]-b[0])**2 + (a[1]-b[1])**2) ** 0.5

        # inputs from event (if present)
        total_att = int(event.get("attendees_estimate") or sum(
            sum(gates.values()) for gates in df_group.values()
        ))
        safe_zones = event.get("safe_zones", []) or []
        closed = set(event.get("closed_nodes", []))
        # candidate gates/exits (only nodes with type 'gate' or 'exit' and not closed)
        candidate_nodes = []
        for nid, r in nodes.items():
            typ = (r.get("type") or "").strip().lower()
            if typ in ("gate","exit") and nid not in closed:
                # get capacity (fall back to gate_cap if present)
                try:
                    cap = int(r.get("gate_capacity_ppm") or r.get("capacity_ppm") or gate_cap.get(nid) or 120)
                except Exception:
                    cap = gate_cap.get(nid, 120)
                candidate_nodes.append({"id": nid, "type": typ, "cap": cap, "coord": coord(nid)})

        # If no candidate gates found, fall back to any gate in gate_cap
        if not candidate_nodes:
            for nid, c in gate_cap.items():
                candidate_nodes.append({"id": nid, "type": "gate", "cap": c, "coord": coord(nid)})

        # compute nearest gate(s) for each safe zone (if safe_zone name maps to a node)
        plan = []
        used_gates = set()
        total_exit_capacity = sum(n["cap"] for n in candidate_nodes)
        # fallback: if no safe_zones named in venue nodes, create 2 pseudo safe-zones: "ExternalAssembly1","ExternalAssembly2"
        valid_safe_zones = [sz for sz in safe_zones if sz in nodes]
        if not valid_safe_zones:
            # try common names (CarParkA etc.) else fall back to nearest exits grouped
            valid_safe_zones = []
            # try nodes that look like parking / concourse / plaza
            for guess in ["Park1","ConcN","ConcS","PlazaNorth","CarParkA"]:
                if guess in nodes:
                    valid_safe_zones.append(guess)
            if not valid_safe_zones:
                # use first two gate-adjacent placeholders (map to coordinates of top candidate gates)
                cand_sorted = sorted(candidate_nodes, key=lambda x: -x["cap"])
                for i, c in enumerate(cand_sorted[:2]):
                    placeholder = f"SafeZone_{i+1}"
                    # create pseudo-node entry so coord lookup works
                    nodes[placeholder] = {"name": placeholder, "x": c["coord"][0]+5, "y": c["coord"][1]+5}
                    valid_safe_zones.append(placeholder)

        # assign gates to safe zones by nearest + capacity until capacities used up
        # We'll use greedy: for each safe zone, pick up to 2 best nearby gates
        for sz in valid_safe_zones:
            sz_coord = coord(sz)
            # score candidate gates by distance (closer better) and capacity
            sorted_gates = sorted(candidate_nodes, key=lambda x: (dist(x["coord"], sz_coord), -x["cap"]))
            # pick top 2 that are not closed and not already overloaded
            picks = []
            for g in sorted_gates:
                if g["id"] in used_gates:
                    continue
                picks.append(g)
                used_gates.add(g["id"])
                if len(picks) >= 2:
                    break
            if not picks and sorted_gates:
                picks = [sorted_gates[0]]
                used_gates.add(sorted_gates[0]["id"])
            # estimated capacity toward this safe_zone = sum picks caps
            cap_sum = sum(p["cap"] for p in picks) or 1
            # allocate a share of total attendees proportional to cap_sum vs total_exit_capacity
            share = int(round(total_att * (cap_sum / max(1, total_exit_capacity))))
            # estimate clear time (minutes) = share / cap_sum rounded up
            est_minutes = int((share + cap_sum - 1) // cap_sum)
            plan.append({
                "safe_zone": sz,
                "assigned_gates": [p["id"] for p in picks],
                "assigned_capacity_ppm": cap_sum,
                "estimated_people_assigned": share,
                "estimated_clear_minutes": est_minutes
            })

        # If some candidate gates remain unused, recommend them as overflow
        overflow = [c["id"] for c in candidate_nodes if c["id"] not in used_gates]
        marshal_needed = max(1, int((total_att / 500)))  # heuristic: 1 marshal per 500 evacuees

        # create structured actions for PublishAlerts
        for p in plan:
            actions.append({
                "ts": tmax,
                "action": f"Evacuate to {p['safe_zone']} via {', '.join(p['assigned_gates'])}",
                "safe_zone": p['safe_zone'],
                "recommended_gates": p['assigned_gates'],
                "estimated_people": p['estimated_people_assigned'],
                "estimated_clear_minutes": p['estimated_clear_minutes'],
                "marshal_required": max(1, int(p['estimated_people_assigned'] / 500))
            })

        # add a summary action
        actions.append({
            "ts": tmax,
            "action": "Phased egress: sector assignments and marshal dispatch",
            "summary": {
                "total_attendees": total_att,
                "total_exit_capacity_ppm": total_exit_capacity,
                "overall_est_clear_minutes": int((total_att + total_exit_capacity - 1) // max(1, total_exit_capacity)),
                "overflow_gates": overflow,
                "marshal_total_required": marshal_needed
            }
        })
    # --- end evacuation planner ---

    prefix = f"scenarios/{scenario}/{int(time.time())}/"
    s3.put_object(Bucket=OUTPUT_BUCKET, Key=prefix+"hotspots.json", Body=json.dumps(hotspots).encode())
    s3.put_object(Bucket=OUTPUT_BUCKET, Key=prefix+"actions.json", Body=json.dumps(actions).encode())

    put_metric("HotspotCount", len(hotspots), [{"Name":"Scenario","Value":scenario}])

    return {"statusCode":200, "outputs":{"s3_prefix": prefix, "hotspots": len(hotspots), "actions": len(actions)}}
